﻿using Microsoft.AspNetCore.Identity;

namespace SampleMvcWebAppWithUi.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}