﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ViewBag_Multiple_Records.Models
{
    public class Student
    {
        public int stuId { get; set; }
        public string stuName { get; set; }
        public string stuEmail { get; set; }
        public string stuContact { get; set; }
        public string stuAddress { get; set; }

    }
}