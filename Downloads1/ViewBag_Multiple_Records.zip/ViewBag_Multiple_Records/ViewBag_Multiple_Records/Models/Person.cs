﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ViewBag_Multiple_Records.Models
{
    public class Person
    {
        public string PersonName { get; set; }
        public string PersonEmail { get; set; }
        public string PersonContact { get; set; }
        public string PersonAddress { get; set; }

    }
}