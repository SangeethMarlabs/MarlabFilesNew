﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ViewBag_Multiple_Records.Models
{
    public class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public float EmpSal { get; set; }

    }
}