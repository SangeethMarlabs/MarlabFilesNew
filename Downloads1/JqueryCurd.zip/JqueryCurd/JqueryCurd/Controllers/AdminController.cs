﻿using JqueryCurd.Models;
using JqueryCurd.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JqueryCurd.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult AdminPage()

        {
            return View();
        }

        public JsonResult GetCountry()
        {
            EmployeeRepository _emp = new EmployeeRepository();
            return Json(_emp.GetCountry());
        }
        public JsonResult GetState(int CountryId)
        {
            EmployeeRepository _emp = new EmployeeRepository();
            return Json(_emp.GetState(CountryId));
        }
        public JsonResult GetCity(int StateId)
        {
            EmployeeRepository _emp = new EmployeeRepository();
            return Json(_emp.GetCity(StateId));

        }
        public JsonResult SaveUser(UserLogin UserDetails)
        {
            EmployeeRepository _emp = new EmployeeRepository();
            return Json(_emp.SaveUserDetails(UserDetails));
        }
    }
}
