﻿using JqueryCurd.Models;
using JqueryCurd.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace JqueryCurd.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public JsonResult List()
        {
            EmployeeRepository _objemp = new EmployeeRepository();
            return Json(_objemp.ListAllEmployeeDetails());
        }

        public JsonResult AddDetails(Employee emp)
        {
            EmployeeRepository _objemp = new EmployeeRepository();
            return Json(_objemp.AddEmployeeDetails(emp));
        }

        [HttpGet]
        public JsonResult Delete(int Id)
        {
            EmployeeRepository _objemp = new EmployeeRepository();
            return Json(_objemp.DeleteDetails(Id));
        }
        [HttpPost]
        public JsonResult UpdateDetails(Employee emp)
        {
            EmployeeRepository _objemp = new EmployeeRepository();

            return Json(_objemp.Update(emp));
        }
        public JsonResult SelectEmployeebyId(int EmployeeId)
        {
            EmployeeRepository _objemp = new EmployeeRepository();
            return Json(_objemp.ListAllEmployeeDetails().Find(x => x.EmployeeID.Equals(EmployeeId)));

        }


        //[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        //public IActionResult Error()
        //{
        //    return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });

        //}
    }
}

