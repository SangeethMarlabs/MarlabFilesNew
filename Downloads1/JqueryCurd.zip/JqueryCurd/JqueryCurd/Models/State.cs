﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JqueryCurd.Models
{
    public class State
    {
        public int StateId { get; set; }
        public String StateName { get; set; }
    }
}
