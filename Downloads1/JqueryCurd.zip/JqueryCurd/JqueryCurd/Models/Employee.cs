﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JqueryCurd.Models
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public int Age { get; set; }
        public string State { get; set; }
        public string Country { get; set; }

    }
}
