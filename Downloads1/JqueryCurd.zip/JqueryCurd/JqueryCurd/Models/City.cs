﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JqueryCurd.Models
{
    public class City
    {
        public int CityId { get; set; }

        public String CityName { get; set; }
    }
}
