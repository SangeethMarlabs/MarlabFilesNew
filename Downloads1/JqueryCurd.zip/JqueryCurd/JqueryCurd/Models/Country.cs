﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JqueryCurd.Models
{
    public class Country
    {
        public int CountryId { get; set; }

        public string CountryName { get; set; }
    }
}
public class states
{
    public int StateId { get; set; }
    public String StateName {get;set;}
}
