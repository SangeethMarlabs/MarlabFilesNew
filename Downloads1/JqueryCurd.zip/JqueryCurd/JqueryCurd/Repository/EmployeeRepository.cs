﻿using JqueryCurd.Helper;
using JqueryCurd.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace JqueryCurd.Repository
{
    public class EmployeeRepository
    {
        //Connection String
        String cs = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Dropdown;Integrated Security=True";

        //Return List Of Employees

        public List<Employee> ListAllEmployeeDetails()
        {
            List<Employee> _emplist = new List<Employee>();
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand(Constant.USER_SELECT_EMPLOYEE, con);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    _emplist.Add(new Employee
                    {
                        EmployeeID = Convert.ToInt32(dr["EmployeeID"]),
                        FName = dr["FName"].ToString(),
                        LName = dr["LName"].ToString(),
                        Age = Convert.ToInt32(dr["Age"]),
                        State = dr["State"].ToString(),
                        Country = dr["Country"].ToString(),

                    });
                }
            }
            return _emplist;


        }

        public int AddEmployeeDetails(Employee emp)
        {
            int i;
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand(Constant.USER_INSERT_DETAILS, con);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@FName", emp.FName);
                com.Parameters.AddWithValue("@LName", emp.LName);
                com.Parameters.AddWithValue("@Age", emp.Age);
                com.Parameters.AddWithValue("@State", emp.State);
                com.Parameters.AddWithValue("@Country", emp.Country);
                com.Parameters.AddWithValue("@Action", "Insert");
                i = com.ExecuteNonQuery();
            }
            return i;
        }
        public int DeleteDetails(int Id)
        {
            int i;
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand(Constant.USER_DELETE, con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@Id", Id);
                i = com.ExecuteNonQuery();
            }
            return i;
        }
        //Method for Updating Employee record  
        public int Update(Employee emp)
        {
            int i;
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand(Constant.USER_INSERT_DETAILS, con);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@Id", emp.EmployeeID);
                com.Parameters.AddWithValue("@FName", emp.FName);
                com.Parameters.AddWithValue("@LName", emp.LName);
                com.Parameters.AddWithValue("@Age", emp.Age);
                com.Parameters.AddWithValue("@State", emp.State);
                com.Parameters.AddWithValue("@Country", emp.Country);
                com.Parameters.AddWithValue("@Action", "Update");
                i = com.ExecuteNonQuery();
            }
            return i;
        }

        public List<Country> GetCountry()
        {
            List<Country> _objCountry = new List<Country>();

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand(Constant.USER_GET_LIST_COUNTRY, con);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    _objCountry.Add(new Country
                    {
                        CountryId = Convert.ToInt32(dr["CountryId"]),
                        CountryName = dr["CountryName"].ToString(),

                    });
                }
            }

            return _objCountry;
        }
        public List<State> GetState(int CountryId)
        {
            List<State> _objState = new List<State>();

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand(Constant.USER_GET_LIST_STATE, con);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@CountryID", CountryId);
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    _objState.Add(new State
                    {
                        StateId = Convert.ToInt32(dr["StateId"]),
                        StateName = dr["StateName"].ToString(),

                    });
                }
            }

            return _objState;

        }
        public List<City> GetCity(int StateId)
        {
            List<City> _objCity = new List<City>();

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand(Constant.USER_GET_LIST_CITY, con);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@StateID", StateId);
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    _objCity.Add(new City
                    {
                        CityId = Convert.ToInt32(dr["CityId"]),
                        CityName = dr["CityName"].ToString(),

                    });
                }
            }

            return _objCity;
        }

        public int SaveUserDetails(UserLogin UserDetails)
        {
            int i;
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand(Constant.USER_SAVE_DETAILS, con);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@UserName", UserDetails.UserName);
                com.Parameters.AddWithValue("@UserEmail", UserDetails.UserEmail);
                com.Parameters.AddWithValue("@UserPassword", UserDetails.UserPassword);
                com.Parameters.AddWithValue("@UserCity", UserDetails.UserCity);


                i = com.ExecuteNonQuery();
            }
            return i;

        }
    }
}