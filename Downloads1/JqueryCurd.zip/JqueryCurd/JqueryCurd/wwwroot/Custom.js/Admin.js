﻿$(document).ready(function () {

    AdminOperations.selectcountry();

    $('#ddlCountry').change(function () {

        AdminOperations.selectState(this.value);

    });

    $('#ddlState').change(function () {
        AdminOperations.selectCity(this.value);
    });
    $('#btnSave').click(function () {
        
        var UserObj = {
            UserId: 0,
            UserName:$('#txtName').val(),
            UserEmail: $('#txtEmail').val(),
            USerPassword: $('#txtPassword').val(),
            UserCity: $('#ddlCity').val(),

        };
      

        AdminOperations.SaveUserDetails(UserObj);
});


});


var AdminOperations = {



    selectcountry: function () {

        $.ajax({
            url: "/Admin/GetCountry",
            type: "GET",
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            success: function (result) {
                var html = '';
                $.each(result, function (key, item) {
                    $("#ddlCountry").append(
                        $("<option></option>").val(item.countryId).html(item.countryName));
                });

            },
            error: function (errormessgae) {
                alert(errormessgae);
            }

        });

    },
    selectState: function (CountryId) {
        $.ajax({
            url: "/Admin/GetState",
            type: "GET",
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            data: { "CountryId": CountryId },
            success: function (result) {
                var html = '';
                var dropdown = $('#ddlState');
                dropdown.empty();
                var dropdown = $('#ddlCity');
                dropdown.empty();
                $("#ddlState").append(
                    $("<option></option>").val(0).html("Select"));
                $("#ddlCity").append(
                    $("<option></option>").val(0).html("Select"));
                $.each(result, function (key, item) {
                    $("#ddlState").append(
                        $("<option></option>").val(item.stateId).html(item.stateName));
                });

            },
            error: function (errormessgae) {
                alert(errormessgae);
            }

        });

    },
    selectCity: function (StateId) {
        $.ajax({
            url: "/Admin/GetCity",
            type: "GET",
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            data: { "StateId": StateId },
            success: function (result) {
                var html = '';
                var dropdown = $('#ddlCity');
                dropdown.empty();
                $("#ddlCity").append(
                    $("<option></option>").val(0).html("Select"));
                $.each(result, function (key, item) {
                    $("#ddlCity").append(
                        $("<option></option>").val(item.cityId).html(item.cityName));
                });

            },
            error: function (errormessgae) {
                alert(errormessgae);
            }

        });
    },

    SaveUserDetails: function (Userdata) {
        $.ajax({
            url: "/Admin/SaveUser",
            type: "GET",
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            data: Userdata,
            success: function (result) {
                if (result == true) {
                    Clearform();
                    alert("Records added succesfully")
                }

            },
            error: function (errormessgae) {
                alert(errormessgae);
            }

        });

    }
}
function Clearform() {
    $('#txtName').val("");
    $('#txtEmail').val("");
    $('#txtPassword').val("");
    var dropdown = $('#ddlCity');
    dropdown.empty();
    $("#ddlCity").append(
        $("<option></option>").val(0).html("Select"));
    var dropdown = $('#ddlState');
    dropdown.empty();
    $("#ddlState").append(
        $("<option></option>").val(0).html("Select"));
    var dropdown = $('#ddlCountry');
    dropdown.empty();
    $("#ddlCountry").append(
        $("<option></option>").val(0).html("Select"));
}