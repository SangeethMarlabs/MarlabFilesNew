﻿$(document).ready(function(){
    //alert("Hi");
    EmployeeOperations.SelectEmployee();
});


var EmployeeOperations = {

    SelectEmployee: function () {
        $.ajax({

            url: "/Home/List",
            type: "GET",
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            success: function (result) {
                var html = '';
                $.each(result, function (key, item) {
                    html += '<tr>';
                    html += '<td>' + item.employeeID + '</td>'
                    html += '<td>' + item.fName + '</td>'
                    html += '<td>' + item.lName + '</td>'
                    html += '<td>' + item.age + '</td>'
                    html += '<td>' + item.state + '</td>'
                    html += '<td>' + item.country + '</td>'
                    html += '<td> <a href="#" onclick="return getbyId(' + item.employeeID + ')">Edit</a> |<a href="#" onclick=" return Delete(' + item.employeeID + ')">Delete</a></td>';
                   // html += '<td><a href="#" data-bs-toggle="modal" data-bs-target="#myModal1" onclick="popup1()">Edit</a></td>';
                  //  html += '<td> < a href = "#" data - bs - toggle="modal" data - bs - target="#myModal1" onclick = "popup1()" > Delete</a ></td > ';
                   html += '</tr>'



                });
                $('.tbody').html(html);
            },
            error: function (errormessage) {
                alert(errormessage);
            }
        });
    }
}

function popup() {
    $("#myModalInsert").modal("show");
}
//function popup1() {
   // $("#myModal1").modal('show');
//}

function Add() {
    var res = Validate()
    if (res == false) {
        return false
    }

    var empObj = {
        FName:    $("#txtfname").val(),
        LName:    $("#txtlname").val(),
        Age:      $("#txtAge").val(),
        State:     $("#txtState").val(),
        Country:    $("#txtCountry").val()
    };
    $.ajax({
        type: 'POST',
        dataType: 'JSON',
        data: empObj,
        url:'/Home/AddDetails',
        success: function (result) {
            EmployeeOperations.SelectEmployee();
            $("#myModalInsert").modal('hide');
           
        },
        error: function (errormessage) {
            alert(errormessage);
        }
    });
}
function Validate() {
    var isValid = true;
    if ($("#txtfname").val().trim() == "") {

        $("#txtfname").css('border-color', 'Red');
        isValid == false;
    }
    if ($("#txtlname").val().trim()== "") {

        $("#txtlname").css('border-color', 'Red');
        isValid == false;
    }
    if ($("#txtAge").val().trim() == "") {

        $("#txtAge").css('border-color', 'Red');
        isValid == false;
    }
    if ($("#txtState").val().trim() == "") {

        $("#txtState").css('border-color', 'Red');
        isValid == false;
    }
    if ($("#txtCountry").val().trim() == "") {

        $("#txtCountry").css('border-color', 'Red');
        isValid == false;
    }
    return isValid;


   

}

function getbyId(empid) {
    //alert(empid)
   // $("#myModalUpdate").modal('show');
    $("#txtupdateempid").val(empid);
    $.ajax({
        url: "/Home/SelectEmployeebyId",
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        data: { "EmployeeID": empid },
        success: function (result) {
            $("#txtupdatefname").val(result.fName);
            $("#txtupdatelname").val(result.lName);
            $("#txtupdateAge").val(result.age);
            $("#txtupdateState").val(result.state);
            $("#txtupdateCountry").val(result.country);
            $("#myModalUpdate").modal('show');
            
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}









function Delete(Id) {
    $.ajax({
        url: "/Home/Delete",
        type: 'GET',
        contentType: 'application/json;charset=utf-8',
        dataType: 'json',
        data: { Id: Id },
        success: function () {
            alert('delete success !!');
            EmployeeOperations.selectEmployees()

        },
        error: function () {
            alert('Delete the details !');
        }
    });
   
}



//function for updating employee's record  
function UpdateEmp() {
    var res = ValidateforUpdate()
    if (res == false) {
        return false
    }
    var empObj = {
        EmployeeID: $("#txtupdateempid").val(),
        FName: $("#txtupdatefname").val(),
        LName: $("#txtupdatelname").val(),
        Age: $("#txtupdateAge").val(),
        State: $("#txtupdateState").val(),
        Country: $("#txtupdateCountry").val()

    };
    $.ajax({
        type: 'POST',
        dataType: 'JSON',
        data: empObj,
        url: '/Home/UpdateDetails',
        success: function (result) {
            $("#myModalInsert").modal('hide');
            EmployeeOperations.SelectEmployee();
           
        },
        error: function (errormessage) {
            alert(errormessage);
        }
    });
}

    function ValidateforUpdate() {
        var isValid = true;
        if ($("#txtupdatefname").val().trim() == "") {

            $("#txtfname").css('border-color', 'Red');
            isValid == false;
        }
        if ($("#txtupdatelname").val().trim() == "") {

            $("#txtlname").css('border-color', 'Red');
            isValid == false;
        }
        if ($("#txtupdateAge").val().trim() == "") {

            $("#txtAge").css('border-color', 'Red');
            isValid == false;
        }
        if ($("#txtupdateState").val().trim() == "") {

            $("#txtState").css('border-color', 'Red');
            isValid == false;
        }
        if ($("#txtupdateCountry").val().trim() == "") {

            $("#txtCountry").css('border-color', 'Red');
            isValid == false;
        }
        return isValid;

    }

