﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JqueryCurd.Helper
{
    public class Constant
    {

        #region SQL -SP Names
        public const string USER_SAVE_DETAILS = "usp_SaveUserDetails";

        public const string USER_GET_LIST_CITY = "usp_SelectCitylist";

        public const string USER_GET_LIST_STATE = "usp_SelectStatelist";

        public const string USER_GET_LIST_COUNTRY = "usp_SelectCountry";

        public const string USER_INSERT_DETAILS = "usp_InsertUpdateEmployee";

        public const string USER_DELETE = "usp_DeleteEmployee";

        public const string USER_SELECT_EMPLOYEE = "usp_SelectEmployee";

        #endregion SQL - SPNames
    }
}