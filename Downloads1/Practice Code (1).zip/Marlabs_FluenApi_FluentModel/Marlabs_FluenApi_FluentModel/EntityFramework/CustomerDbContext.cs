﻿using Marlabs_FluenApi_FluentModel.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Marlabs_FluenApi_FluentModel.EntityFramework
{
    public class CustomerDbContext:DbContext
    {
        public CustomerDbContext(DbContextOptions opt) : base(opt)
        {
        }
        public DbSet<Customer> Customers { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            new CustomerMap(modelBuilder.Entity<Customer>());
        }
    }
}
