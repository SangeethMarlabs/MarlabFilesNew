﻿using Marlabs_FluenApi_FluentModel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Marlabs_FluenApi_FluentModel.Repository
{
    public interface ICustomerRepository
    {
        IEnumerable<Customer> GetCustomer();
        Customer SearchCustomer(int id);
        int UpdateCustomer(Customer customer);
        int CreateCustomer(Customer customer);
        int DeleteCustomer(Customer customer);
    }
}
