﻿using Marlabs_FluenApi_FluentModel.Models;
using Marlabs_FluenApi_FluentModel.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Marlabs_FluenApi_FluentModel.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerRepository icustomerRepository;
        public CustomerController(ICustomerRepository _icustomerRepository)
        {
            icustomerRepository = _icustomerRepository;
        }
        [HttpPost("Create")]
        public ActionResult CreateCustomer(Customer customer)
        {
            return Ok(icustomerRepository.CreateCustomer(customer));
        }
        [HttpGet("CustomerList")]
        public ActionResult GetCustomersList()
        {
            return Ok(this.icustomerRepository.GetCustomer());
        }
        [HttpGet("SearchCustomerById")]
        public ActionResult SearchCustomer(int customerId)
        {
            return Ok(this.icustomerRepository.SearchCustomer(customerId));
        }
        [HttpPut("UpdateCustomer")]
        public ActionResult UpdateCustomer(Customer customer)
        {
            return Ok(this.icustomerRepository.UpdateCustomer(customer));
        }
        [HttpDelete("DeleteCustomer")]
        public ActionResult DeleteCustomer(Customer customer)
        {
            return Ok(this.icustomerRepository.DeleteCustomer(customer));
        }
    }



}