﻿using Domain.Model.Login;
using Microsoft.AspNetCore.Mvc;
using Services.Login;
using System.Collections.Generic;
using System;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Http;
using Services;
using ShoppingApp.Models;
using Services.Dashboard;
using Domain.Model.Dashboard;

namespace ShoppingApp.Controllers
{
    public class LoginController : Controller
    {
        public ILoginRepository LoginRepository;
        private readonly IDashboardRepository dashboardRepository;

        public LoginController(ILoginRepository _loginRepository,IDashboardRepository _dashboardRepository)
        {
            LoginRepository = _loginRepository;
            dashboardRepository= _dashboardRepository;
        }

        // [HttpGet("GetLoginCustomer")]
        [HttpGet]
        public IActionResult LoginCustomer()
        {

            List<string> roles = new List<string>();
            foreach (var role in Enum.GetNames(typeof(Roles)))
            {
                roles.Add(role);
            }

            //ViewData["Roles"] = roles;
            return View("~/Views/CustomerLogin/LoginCustomer.cshtml", roles);
            //  return View(roles);
        }

       

      
        [HttpPost]
        public IActionResult LoginCustomer(string email, string password)
        {
           
            string passwd = EncDec.Encrypt(password);

            var user = LoginRepository.GetUserByEmail(email, password);
            if (user != null)
            {
                var token = GenerateJwtToken(user.email, user.Id, user.Role);
                //Session["Token"] = "";
                HttpContext.Session.SetString("token", token);
                ViewBag.Token = token;
                ViewData["to"] = token;
                List<Productlist> productlist = new List<Productlist>();
                IEnumerable<Productlist> products = productlist;
                products = dashboardRepository.GetAllProduct();

                return View("~/Views/Dashboard/Product.cshtml",products);
            }
            return BadRequest("User Not found");
        }


        private string GenerateJwtToken(string email, long id, string role)
        {
            var securityKey = Encoding.UTF8.GetBytes("this is my custom Secret key for authentication");
            var issuer = "TokenAuthDemo";
            var claims = new[]
                {
                new Claim(ClaimTypes.Role, role),
                new Claim("Email", email),
                new Claim("Id", id.ToString())
            };
            var credentials = new SigningCredentials(new SymmetricSecurityKey(securityKey), SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                    issuer,
                    issuer,
                    claims,
                    expires: DateTime.Now.AddDays(10),
                    signingCredentials: credentials
                );
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        //Customer logout
        [HttpGet("LogoutCustomer")]
        public IActionResult LogoutCustomer()
        {
            HttpContext.Session.Clear();
            return View("~/Views/CustomerLogin/LoginCustomer.cshtml");
        }



    }
}
