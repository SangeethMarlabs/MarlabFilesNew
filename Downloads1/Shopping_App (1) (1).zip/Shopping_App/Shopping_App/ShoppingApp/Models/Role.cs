﻿namespace ShoppingApp.Models
{
	public class Role
	{
	}
}
