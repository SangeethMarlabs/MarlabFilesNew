import './App.css';
import Autoturn from './component/Autoturn'
import Reaction  from './component/Reaction';
// import WhenStatement from './component/WhenStatement'
function App() {
  return (
   <>
  
   <Autoturn/>
   <Reaction />

   {/* <WhenStatement/> */}
   </>
  );
}

export default App;
