﻿namespace Domain.Model.User
{
    public static class Role
    {
        public const string Admin = "Admin";
        public const string Customer = "Customer";
    }
}
