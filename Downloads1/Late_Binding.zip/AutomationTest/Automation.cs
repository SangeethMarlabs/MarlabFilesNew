using System;
using System.IO;
using System.Text;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using Automation;

namespace AutomationTest
{
    public partial class Automation : Form
    {
        WordAutomation _automation = new WordAutomation();
        public Automation()
        {
            InitializeComponent();
            _automation.CreateWordApplication();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "All word documents|*.doc;*.docx";
            if (DialogResult.OK == dlg.ShowDialog(this))
            {
                if (File.Exists(dlg.FileName))
                {           
                    _automation.CloseWordDoc(true);
                    _automation.CreateWordDoc(
                        dlg.FileName, false);
                    txtFileName.Text = dlg.FileName;
                }
            }
        }

        private void btnGetCount_Click(object sender, EventArgs e)
        {
            lblCount.Text = string.Empty;
            if (_automation != null)
            {
                if (txtFind.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Enter a text to find.", AppName,
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                int count = _automation.GetWordCount(txtFind.Text.Trim());
                lblCount.Text = count.ToString();
            }
            else
            {
                MessageBox.Show("Open a valid document to continue.", AppName,
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        public string AppName
        {
            get
            {
                return "Word Automation";
            }
        }

        private void Automation_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_automation != null)
            {
                _automation.CloseWordDoc(true);
                _automation.CloseWordApp();
            }
        }

        private void btnReplaceAll_Click(object sender, EventArgs e)
        {
            if (_automation != null)
            {
                if (txtFind.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Enter a text to find.", AppName,
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (txtReplace.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Enter a text to replace.", AppName,
                       MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                _automation.FindReplace(txtFind.Text.Trim(), txtReplace.Text.Trim());

                MessageBox.Show("Replaced successfully.", AppName,
                       MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Open a valid document to continue.", AppName,
                       MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}