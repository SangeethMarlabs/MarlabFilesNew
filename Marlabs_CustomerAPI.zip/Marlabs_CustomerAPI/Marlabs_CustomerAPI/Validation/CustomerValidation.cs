﻿using FluentValidation;
using Marlabs_CustomerAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Marlabs_CustomerAPI.Validation
{
    public class CustomerValidation : AbstractValidator<Customer>
    {
        public CustomerValidation()
        {
            RuleFor(e => e.CustomerId).NotNull();
            RuleFor(e => e.CustomerName).Length(0, 10).WithMessage("Customer Name must not exceed more than 10 characters");
            RuleFor(c => c.CustomerName).NotNull().WithMessage("Customer name should not be empty");
            RuleFor(c => c.CustomerEmail).EmailAddress().WithMessage("Customer email should not be proper format");
            RuleFor(c => c.CustomerAge).InclusiveBetween(10, 50).WithMessage("Customer age must be between 10 to 50");
            RuleFor(c => c.CustomerContact).MinimumLength(10).MaximumLength(15).WithMessage("Customer phone number must be between 10 to 15 characters");
            RuleFor(c => c.CustomerAddress).MinimumLength(10).MaximumLength(15).WithMessage("Customer Address must be between 10 to 15 characters");
        }
    }
}
