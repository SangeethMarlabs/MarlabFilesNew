﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Marlabs_CustomerAPI.Models
{
    public class CustomerMap
    {
        public CustomerMap(EntityTypeBuilder<Customer> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(cust => cust.CustomerId);
            entityTypeBuilder.Property(cust => cust.CustomerId).IsRequired();
            entityTypeBuilder.Property(cust => cust.CustomerName).IsRequired();
            entityTypeBuilder.Property(cust => cust.CustomerAge).IsRequired();
            entityTypeBuilder.Property(cust => cust.CustomerName).HasMaxLength(50);
            entityTypeBuilder.Property(cust => cust.CustomerContact).IsRequired();
            entityTypeBuilder.Property(cust => cust.CustomerCountry).IsRequired();
            entityTypeBuilder.Property(cust => cust.CustomerState).IsRequired();
            entityTypeBuilder.Property(cust => cust.CustomerCity).IsRequired();
            entityTypeBuilder.Property(cust => cust.CustomerEmail).IsRequired();
        }
    }
}
