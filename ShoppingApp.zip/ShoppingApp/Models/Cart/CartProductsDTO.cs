﻿namespace ShoppingApp.Models.Cart
{
    public class CartProductsDTO
    {
        public int userId { get; set; }
        public int productId { get; set; }
        public int count { get; set; }
    }
}
