﻿using System.ComponentModel.DataAnnotations;

namespace Domain.Model.Login
{
    public class LoginInfo : BaseEntity
    {
        [Required]
        public string email { get; set; }
        [DataType(DataType.Password)]
        public string password { get; set; }
        public string role { get; set; }
    }
}
