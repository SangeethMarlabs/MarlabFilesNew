import './Todo.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Component } from 'react';
import React from 'react';
import SvgTrash from './SvgTrash';

export default class Todo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            items: [],
            newTodo: ""
        }
    }
    render() {
        return (
            <div className="form-group col-md-4 container">

                <h1>Todo List</h1>
                <hr />
                <form>



                    <label for="todotxt">To do item </label>
                    
                    <div>
                        <input className="form-control" type="text" id="todotxt" placeholder="Enter Todo item" onChange={this.txtChange} />
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '5px' }}>
                        <button className="btn btn-primary" type="button" onClick={this.AddItem}>Save</button>
                    </div>
                    
                    <hr />
                    <div>

                        {this.state.items.map((itm, k) => {
                            return (
                                <table>
                                    <tr>
                                        <th></th>
                                    </tr>
                                    <tr>
                                        <td>{k + 1}</td>
                                        <td>{itm}</td>
                                        <td>
                                            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                                                <button type="button" class="btn btn-danger" onClick={() => this.RemoveItem(k)}><SvgTrash />Remove</button>
                                            </div>
                                        </td>
                                    </tr>
                                </table>
                            );
                        })}
                    </div>
                </form>
            </div>

        );
    }

    txtChange = (e) => {
        this.setState({ newTodo: e.target.value });
    }

    AddItem = (e) => {
        const newArr = this.state.items;
        newArr.push(this.state.newTodo);
        this.setState({ items: newArr });
    }

    RemoveItem = (i) => {
        const newArr = this.state.items;
        newArr.splice(i, 1);
        this.setState({ items: newArr });
    }
}

