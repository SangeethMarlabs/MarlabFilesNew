﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Login.Login
{
    public class ForgetModel
    {
        public string JwtToken { get; set; }

    }
}
