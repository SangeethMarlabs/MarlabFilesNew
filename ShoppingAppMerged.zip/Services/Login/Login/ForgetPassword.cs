﻿namespace ShoppingApp.Models.Login
{
    public class ForgetPassword
    {
        public string Email { get; set; }
        public string JwtToken { get; set; }
    }
}
