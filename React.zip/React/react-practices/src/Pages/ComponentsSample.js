function ComponentsSample() {
    return (
        <div>
            <h1>Welcome func component</h1>
        </div>
    );
}
export default ComponentsSample;