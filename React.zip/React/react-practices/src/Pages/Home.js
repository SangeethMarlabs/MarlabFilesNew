import { Component } from "react";
class Home extends Component {
    state = {  }
    render() { 
        return ( 
        <h1>Welcome Home</h1> 
        );
    }
}
 
export default Home;