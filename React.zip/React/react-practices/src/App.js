import ComponentsSample from './Pages/ComponentsSample';
import Home from './Pages/Home';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import NoPage from './Pages/NoPage';
import Layout from './Pages/Layout';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="ComponentsSample" element={<ComponentsSample />} />        
          <Route path="*" element={<NoPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
export default App;