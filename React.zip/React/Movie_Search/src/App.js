import MovieDashboard from './components/MovieDashboard';
import './App.css';
import Review from './components/Review';
import {  Routes, Route} from "react-router-dom";
import Registrationform from './components/Registrationform';
import Login from './components/Login';
import posed, { PoseGroup } from 'react-pose';

const Modal = <Modal key="modal" className="modal" />
const Shade = <Shade key="shade" className="shade" />

function App() {
  return (
    <PoseGroup>
      {true && [
        <div key="shade" className="shade" />,
        <div key="modal" className="modal" />
      ]}
    </PoseGroup>
  );
}

export default App;
