const Home = () => {
    return ( 
        <div className="container col-md-12 mt-3">
             <h1 style={{color: "#414141"}}>Welcome to React sample routing</h1>
             <img class="col-md-12" src="./Image/react-router.jpg" alt=""></img>         
        </div>        
    )}
  
  export default Home;