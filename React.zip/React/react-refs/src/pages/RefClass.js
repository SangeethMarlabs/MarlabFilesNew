import React from "react";
import InputClass from "./InputClass";

class RefClass extends React.Component {
    constructor(props) {
        super(props) 
        this.childCompRef = React.createRef();
    }

    clickHandler = () => {
        //calling the child component function 
        this.childCompRef.current.foucusInput();
       
        console.log(this.childCompRef);
    }

    render() {
        //to associate the ref with our component
        return (
            <div className="container col-md-12 mt-3">
                <InputClass ref={this.childCompRef} />                 
                <button className="btn btn-primary" onClick={this.clickHandler}>Call child class func</button>
            </div>
        );
    }
}
export default RefClass;