import { useEffect, useRef, forwardRef } from "react";
// Only when using forwardRef, the function component receives two arguments, 
// props and ref (Normally the component only gets the props argument).
const InputFunc = forwardRef((props, ref) => {
    // passing the ref to a DOM element, 
    // so that the parent has a reference to the DOM node
    return <input {...props} ref={ref} />
});

function RefFunction() {
    const inputRef = useRef(null);
    // This effect runs only once after the component mounts (like componentDidMount)
    useEffect(() => {
        // ref on function component is forwarded to a regular DOM element, 
        // so now the parent has access to the DOM node including its focus method.
        // Note that the ref usage is the same as a regular 
        // DOM element, like in example 1!
        inputRef.current.focus();
        inputRef.current.value="Ref in function data";
    }, []);
    return <InputFunc ref={inputRef} />
} export default RefFunction;