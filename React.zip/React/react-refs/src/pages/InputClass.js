import React, { Component } from "react";

class InputClass extends Component {
    constructor(props) {
        super(props);
        this.inputRef = React.createRef(); //create ref
    }

    foucusInput() {
        this.inputRef.current.focus();
        this.inputRef.current.value = "Sample";
    }

    render() {
        return (
            <div>
                <h2>Adding Ref to Class Component</h2>
                <input type="text" ref={this.inputRef} />
            </div>
        );
    }
}
export default InputClass;