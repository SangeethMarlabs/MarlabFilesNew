const Home = () => {
    return ( 
        <div className="container col-md-12 mt-3">
             <img class="col-md-12" src="./Image/react_ref_logo.jpg" alt="React Ref"></img>         
        </div>        
    )}
  
  export default Home;