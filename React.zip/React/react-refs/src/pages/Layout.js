import { Outlet, Link } from "react-router-dom";

const Layout = () => {
  return (
    <>      
        <ul class="nav">
          <li class="nav-item">
            <Link to="/" class="nav-link active" >Home</Link>
          </li>
          <li class="nav-item">
            <Link to="/RefDOM" class="nav-link active" >Ref in DOM</Link>
          </li>
          <li class="nav-item">
            <Link to="/RefClass" class="nav-link active" >Ref in Class</Link>
          </li>
          <li class="nav-item">
            <Link to="/RefFunction" class="nav-link active" >Ref in Function</Link>
          </li>
          <li class="nav-item">
            <Link to="/RefCallback" class="nav-link active" >Callback Ref</Link>
          </li>
        </ul>      
      <Outlet />
    </>
  )
};
export default Layout;