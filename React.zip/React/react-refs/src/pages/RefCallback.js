import { Component } from "react";
class RefCallback extends Component {
    constructor(props) {
        super(props);
        
        this.textInput = null;
        this.setTextInputRef = element => {
            this.textInput = element;
        };
        this.focusTextInput = () => {
            // Focus the text input using the raw DOM API
            this.textInput.focus();
        };
    }

    componentDidMount() {
        // autofocus the input on mount
        this.focusTextInput();
    }

    render() {
        // Use the `ref` callback to store a reference to the text input DOM
        // element in an instance field (for example, this.textInput).
        return (
            <div className="container col-md-12 mt-3">
                <h2>Ref Callback</h2>
                <input type="text" ref={this.setTextInputRef} />
                <input type="button" className="btn btn-primary" value="Focus" onClick={this.focusTextInput} />
            </div>
        );
    }
}
export default RefCallback;