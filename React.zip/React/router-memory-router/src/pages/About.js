import React from "react";  

const About = () => {
    return <h3>About Page</h3>;
  };
export default About;