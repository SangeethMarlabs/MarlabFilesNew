import './App.css';
import CharacterCounter from './CharacterCounter';
import Login from './login';

function App() {
  return ( 
    <CharacterCounter />
  );
}

export default App;
