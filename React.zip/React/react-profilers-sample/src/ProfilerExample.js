import { Profiler } from 'react';
import Form from "./Form";

const callback = (id, phase, actualDuration, startTime,
    baseDuration, commitTime, interactions) => {
    console.log(
        "id " + id + " | " +
        " startTime " + startTime + " | " +
        " actualDuration " + actualDuration +  " | " +
        " baseDuration " + baseDuration + " | " +
        " commitTime " + commitTime + " | " +
        " phase " + phase + " | " +
        " interactions " + interactions
    );
}

function ProfilerExample() {
    return (
        <div className="App">
            <Profiler id="NameInp" onRender={callback}>
                <Form labelname="Name " />
            </Profiler>
        </div>
    );
}

export default ProfilerExample; 