import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Form = (props) => {
	const { labelname } = props;
	const [text, setText] = useState("");

	return <div>
        <div><br /></div>
		<label>
			{labelname} :
			<input
				type="text"
				value={text}
				onChange={e => setText(e.target.value)}
			/>
		</label>
	</div>;
};
export default Form;