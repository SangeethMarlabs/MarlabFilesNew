import './App.css';
import ProfilerExample from './ProfilerExample';

function App() {
  return (
    <ProfilerExample/>
  );
}

export default App;


