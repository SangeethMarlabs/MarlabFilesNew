import React from 'react';
import './index.css'; 
import reportWebVitals from './reportWebVitals';
import ReactDOM from 'react-dom';

//Class component
class Employee extends React.Component {
  render(){
    return <div>
      <h2>Employee Details</h2>
      <hr />
      <p>
        <label>Name : <b>{this.props.Name}</b></label><br />
        <label>Company : <b>{this.props.Company}</b></label><br />
        <label>Department : <b>{this.props.Department}</b></label><br />
        <hr />
      </p>
      </div>;
  }
}

//funtional component
const Samplefuntion=()=>
{
  return <h1>Welcome to Sample function</h1>;
}
 
export default Samplefuntion;

const element=<Employee Name="Sangeeth CS" Company="Marlabs" Department="Dev"/>
//ReactDOM.render(element,document.getElementById("root"));
ReactDOM.render(<Samplefuntion />,document.getElementById("root"));

// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>
// );

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
